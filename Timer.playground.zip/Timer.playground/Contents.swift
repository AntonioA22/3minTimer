import UIKit
//Minutes are converted into seconds
let MaxTime = 180
// time counts to 180 sec
for Timer in 0...MaxTime
    {
    //Prints each second on the time
    print("\(Timer) seconds")
    if Timer == MaxTime{
            print("TIMES UP BUDDY")
    }
    
    }
